import cv2
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report

# Load dataset
dataset = pd.read_csv('labels.csv')
image_folder = 'images/'

def process_image(image_path):
    # Load image
    image = cv2.imread(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Preprocess and threshold to detect optic disc and cup (dummy thresholding here)
    _, thresh = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)

    # Calculate Cup-to-Disc Ratio (CDR)
    # For demonstration, using a dummy CDR calculation
    # Replace with actual optic disc and cup detection logic
    cdr = np.random.uniform(0.4, 0.7)  # Placeholder for demonstration
    return cdr

def classify_image(cdr, threshold=0.5):
    # Classification based on CDR threshold
    return "glaucoma" if cdr > threshold else "normal"

# Arrays to store results
y_true = []
y_pred = []

# Process each image in the dataset
for _, row in dataset.iterrows():
    image_path = image_folder + row['filename']
    true_label = row['label']

    # Process image and classify
    cdr = process_image(image_path)
    predicted_label = classify_image(cdr)

    # Append results for verification
    y_true.append(true_label)
    y_pred.append(predicted_label)

# Calculate accuracy and print results
accuracy = accuracy_score(y_true, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")
print(classification_report(y_true, y_pred))
