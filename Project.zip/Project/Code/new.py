import cv2
import os
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import LabelEncoder

# Define the dataset directory and classes
dataset_dir = 'dataset/'
classes = ['glaucoma', 'normal']

# Function to extract features from an image
def extract_features(image_path):
    # Read image in color and resize
    image = cv2.imread(image_path)
    image = cv2.resize(image, (128, 128))  # Resize to a fixed size

    # Compute color histogram features
    hist = cv2.calcHist([image], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
    hist = cv2.normalize(hist, hist).flatten()
    return hist

# Prepare data and labels
features = []
labels = []

for label in classes:
    class_dir = os.path.join(dataset_dir, label)
    for filename in os.listdir(class_dir):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            image_path = os.path.join(class_dir, filename)
            hist_features = extract_features(image_path)
            features.append(hist_features)
            labels.append(label)

# Convert lists to numpy arrays
X = np.array(features)
y = np.array(labels)

# Encode labels as integers
le = LabelEncoder()
y = le.fit_transform(y)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the SVM classifier
model = SVC(kernel='linear', probability=True)
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")
print(classification_report(y_test, y_pred, target_names=le.classes_))
